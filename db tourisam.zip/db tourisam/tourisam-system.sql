-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 09, 2024 at 06:59 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `tourisam-system`
--

-- --------------------------------------------------------

--
-- Table structure for table `booking`
--

CREATE TABLE `booking` (
  `User_name` varchar(50) DEFAULT NULL,
  `Email_id` varchar(50) NOT NULL,
  `Package` varchar(50) DEFAULT NULL,
  `Trip_days` int(50) DEFAULT NULL,
  `place` varchar(100) DEFAULT NULL,
  `id` int(11) NOT NULL,
  `bookingdate` date DEFAULT NULL,
  `ondate` date DEFAULT NULL,
  `status` text DEFAULT '\'INPROCESS\'',
  `touriscount` int(100) DEFAULT NULL,
  `user_nic_no` varchar(13) NOT NULL,
  `tripamount` varchar(200) DEFAULT NULL,
  `contactno` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `bookingcancel`
--

CREATE TABLE `bookingcancel` (
  `id` int(11) NOT NULL,
  `user_name` varchar(255) NOT NULL,
  `Email_id` varchar(255) NOT NULL,
  `place` varchar(255) NOT NULL,
  `Trip_days` int(11) NOT NULL,
  `ondate` date NOT NULL,
  `bookingdate` date NOT NULL,
  `package` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `touriscount` int(11) NOT NULL,
  `user_nic_no` varchar(13) NOT NULL,
  `tripamount` int(100) DEFAULT NULL,
  `contactno` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `bookingcancel`
--

INSERT INTO `bookingcancel` (`id`, `user_name`, `Email_id`, `place`, `Trip_days`, `ondate`, `bookingdate`, `package`, `status`, `touriscount`, `user_nic_no`, `tripamount`, `contactno`) VALUES
(9, 'zama', 'mohamedinfak123@gmail.com', 'Jaffna', 5, '2024-05-23', '2024-05-21', ' cuple', 'cancel', 2, ' 200116601497', 10000, 770203226),
(10, 'zama', 'mohamedinfak123@gmail.com', 'Jaffna', 5, '2024-05-23', '2024-05-21', ' cuple', 'cancel', 2, ' 200116601497', 10000, 770203226),
(11, 'zama', 'mohamedinfak123@gmail.com', 'Jaffna', 5, '2024-05-23', '2024-05-21', ' cuple', 'cancel', 2, ' 200116601497', 10000, 770203226),
(12, 'nazaha fathima', 'infakstc@gmail.com', 'Jaffna', 5, '2024-05-07', '2024-05-14', ' cuple', 'cancel', 2, ' 200116601497', 10000, 752217426),
(13, 'NISArr', 'infakstc@gmail.com', 'Anuradhapura', 15, '2024-07-07', '2024-07-17', ' solo', 'cancel', 3, ' 200116601497', 8955, 752211311),
(14, 'NISArr', 'infakstc@gmail.com', 'Anuradhapura', 15, '2024-07-07', '2024-07-17', ' solo', 'cancel', 3, ' 200116601497', 8955, 752211311);

-- --------------------------------------------------------

--
-- Table structure for table `bookingconfirmed`
--

CREATE TABLE `bookingconfirmed` (
  `id` int(20) NOT NULL,
  `user_name` text NOT NULL,
  `Email_id` varchar(50) NOT NULL,
  `place` varchar(50) NOT NULL,
  `Trip_days` int(20) NOT NULL,
  `ondate` date NOT NULL,
  `bookingdate` date NOT NULL,
  `status` tinytext DEFAULT NULL,
  `package` tinytext DEFAULT NULL,
  `touriscount` int(10) DEFAULT NULL,
  `user_nic_no` varchar(13) DEFAULT NULL,
  `tripamount` int(100) DEFAULT NULL,
  `contactno` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `enquiries`
--

CREATE TABLE `enquiries` (
  `report_id` int(11) NOT NULL,
  `Email_id` varchar(30) NOT NULL,
  `User_name` text NOT NULL,
  `complaint` varchar(100) NOT NULL,
  `Reportingdate` datetime(6) DEFAULT current_timestamp(6),
  `IncidentDate` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `enquiries`
--

INSERT INTO `enquiries` (`report_id`, `Email_id`, `User_name`, `complaint`, `Reportingdate`, `IncidentDate`) VALUES
(1, ' mohamedinfak123@gmail.com ', ' Mohamed', 'hgjhgjhgjkh', '2024-05-30 19:11:04.741731', '2024-05-30'),
(2, ' mohamedinfak123@gmail.com ', ' Mohamed', 'rdhfh', '2024-06-02 22:40:53.814079', '2024-06-11'),
(3, ' gggg@gmail.com ', ' sfd', 'fsg', '2024-06-02 22:42:51.882170', '2024-06-18');

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `username` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `feedback` varchar(300) NOT NULL,
  `performance` varchar(20) NOT NULL,
  `fid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`username`, `email`, `feedback`, `performance`, `fid`) VALUES
('', 'infakstc@gmail.com', 'sgsfhg', 'Excelante', 89);

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `email` varchar(100) NOT NULL,
  `user-password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`email`, `user-password`) VALUES
('abcd@gmail.com', 'infak'),
('mst', 'password'),
('mst', '5f4dcc3b5aa765d61d8327deb882cf99'),
('mst', 'e99a18c428cb38d5f260853678922e03'),
('abcd@gmail.com', 'e99a18c428cb38d5f260853678922e03'),
('mst', '5f4dcc3b5aa765d61d8327deb882cf99'),
('', 'd41d8cd98f00b204e9800998ecf8427e'),
('', 'd41d8cd98f00b204e9800998ecf8427e'),
('', 'd41d8cd98f00b204e9800998ecf8427e'),
('', 'd41d8cd98f00b204e9800998ecf8427e'),
('', 'd41d8cd98f00b204e9800998ecf8427e'),
('', 'd41d8cd98f00b204e9800998ecf8427e'),
('', 'd41d8cd98f00b204e9800998ecf8427e'),
('', 'd41d8cd98f00b204e9800998ecf8427e'),
('', 'd41d8cd98f00b204e9800998ecf8427e'),
('', 'd41d8cd98f00b204e9800998ecf8427e'),
('', 'd41d8cd98f00b204e9800998ecf8427e'),
('', 'd41d8cd98f00b204e9800998ecf8427e'),
('', 'd41d8cd98f00b204e9800998ecf8427e'),
('', 'd41d8cd98f00b204e9800998ecf8427e'),
('', 'd41d8cd98f00b204e9800998ecf8427e'),
('', 'd41d8cd98f00b204e9800998ecf8427e'),
('', 'd41d8cd98f00b204e9800998ecf8427e'),
('', 'd41d8cd98f00b204e9800998ecf8427e'),
('', 'd41d8cd98f00b204e9800998ecf8427e'),
('', 'd41d8cd98f00b204e9800998ecf8427e'),
('', 'd41d8cd98f00b204e9800998ecf8427e'),
('', 'd41d8cd98f00b204e9800998ecf8427e'),
('', 'd41d8cd98f00b204e9800998ecf8427e'),
('', 'd41d8cd98f00b204e9800998ecf8427e'),
('', 'd41d8cd98f00b204e9800998ecf8427e'),
('', 'd41d8cd98f00b204e9800998ecf8427e'),
('', 'd41d8cd98f00b204e9800998ecf8427e'),
('', 'd41d8cd98f00b204e9800998ecf8427e'),
('', 'd41d8cd98f00b204e9800998ecf8427e'),
('', 'd41d8cd98f00b204e9800998ecf8427e'),
('', 'd41d8cd98f00b204e9800998ecf8427e'),
('', 'd41d8cd98f00b204e9800998ecf8427e'),
('', 'd41d8cd98f00b204e9800998ecf8427e'),
('', 'd41d8cd98f00b204e9800998ecf8427e'),
('', 'd41d8cd98f00b204e9800998ecf8427e'),
('', 'd41d8cd98f00b204e9800998ecf8427e'),
('', 'd41d8cd98f00b204e9800998ecf8427e'),
('', 'd41d8cd98f00b204e9800998ecf8427e'),
('', 'd41d8cd98f00b204e9800998ecf8427e'),
('', 'd41d8cd98f00b204e9800998ecf8427e'),
('', 'd41d8cd98f00b204e9800998ecf8427e'),
('', 'd41d8cd98f00b204e9800998ecf8427e'),
('', 'd41d8cd98f00b204e9800998ecf8427e'),
('', 'd41d8cd98f00b204e9800998ecf8427e'),
('', 'd41d8cd98f00b204e9800998ecf8427e'),
('', 'd41d8cd98f00b204e9800998ecf8427e'),
('', 'd41d8cd98f00b204e9800998ecf8427e'),
('', 'd41d8cd98f00b204e9800998ecf8427e'),
('', 'd41d8cd98f00b204e9800998ecf8427e'),
('', 'd41d8cd98f00b204e9800998ecf8427e'),
('', 'd41d8cd98f00b204e9800998ecf8427e'),
('', 'd41d8cd98f00b204e9800998ecf8427e'),
('', 'd41d8cd98f00b204e9800998ecf8427e'),
('', 'd41d8cd98f00b204e9800998ecf8427e'),
('', 'd41d8cd98f00b204e9800998ecf8427e'),
('', 'd41d8cd98f00b204e9800998ecf8427e'),
('', 'd41d8cd98f00b204e9800998ecf8427e'),
('', 'd41d8cd98f00b204e9800998ecf8427e'),
('', 'd41d8cd98f00b204e9800998ecf8427e'),
('', 'd41d8cd98f00b204e9800998ecf8427e'),
('', 'd41d8cd98f00b204e9800998ecf8427e'),
('', 'd41d8cd98f00b204e9800998ecf8427e'),
('', 'd41d8cd98f00b204e9800998ecf8427e'),
('', 'd41d8cd98f00b204e9800998ecf8427e'),
('', 'd41d8cd98f00b204e9800998ecf8427e'),
('', 'd41d8cd98f00b204e9800998ecf8427e'),
('', 'd41d8cd98f00b204e9800998ecf8427e'),
('', 'd41d8cd98f00b204e9800998ecf8427e'),
('', 'd41d8cd98f00b204e9800998ecf8427e'),
('', 'd41d8cd98f00b204e9800998ecf8427e'),
('', 'd41d8cd98f00b204e9800998ecf8427e'),
('', 'd41d8cd98f00b204e9800998ecf8427e'),
('', 'd41d8cd98f00b204e9800998ecf8427e'),
('', 'd41d8cd98f00b204e9800998ecf8427e'),
('', 'd41d8cd98f00b204e9800998ecf8427e'),
('', 'd41d8cd98f00b204e9800998ecf8427e'),
('', 'd41d8cd98f00b204e9800998ecf8427e'),
('', 'd41d8cd98f00b204e9800998ecf8427e'),
('', 'd41d8cd98f00b204e9800998ecf8427e'),
('', 'd41d8cd98f00b204e9800998ecf8427e'),
('', 'd41d8cd98f00b204e9800998ecf8427e'),
('', 'd41d8cd98f00b204e9800998ecf8427e'),
('', 'd41d8cd98f00b204e9800998ecf8427e'),
('', 'd41d8cd98f00b204e9800998ecf8427e'),
('', 'd41d8cd98f00b204e9800998ecf8427e'),
('', 'd41d8cd98f00b204e9800998ecf8427e'),
('', 'd41d8cd98f00b204e9800998ecf8427e'),
('', 'd41d8cd98f00b204e9800998ecf8427e'),
('', 'd41d8cd98f00b204e9800998ecf8427e'),
('', 'd41d8cd98f00b204e9800998ecf8427e'),
('', 'd41d8cd98f00b204e9800998ecf8427e'),
('', 'd41d8cd98f00b204e9800998ecf8427e'),
('', 'd41d8cd98f00b204e9800998ecf8427e'),
('', 'd41d8cd98f00b204e9800998ecf8427e'),
('', 'd41d8cd98f00b204e9800998ecf8427e'),
('', 'd41d8cd98f00b204e9800998ecf8427e'),
('', 'd41d8cd98f00b204e9800998ecf8427e'),
('', 'd41d8cd98f00b204e9800998ecf8427e'),
('', 'd41d8cd98f00b204e9800998ecf8427e'),
('', 'd41d8cd98f00b204e9800998ecf8427e'),
('', 'd41d8cd98f00b204e9800998ecf8427e'),
('', 'd41d8cd98f00b204e9800998ecf8427e'),
('', 'd41d8cd98f00b204e9800998ecf8427e'),
('mst', '5f4dcc3b5aa765d61d8327deb882cf99'),
('', 'd41d8cd98f00b204e9800998ecf8427e'),
('', 'd41d8cd98f00b204e9800998ecf8427e'),
('', 'd41d8cd98f00b204e9800998ecf8427e'),
('', 'd41d8cd98f00b204e9800998ecf8427e'),
('', 'd41d8cd98f00b204e9800998ecf8427e'),
('', 'd41d8cd98f00b204e9800998ecf8427e'),
('', 'd41d8cd98f00b204e9800998ecf8427e'),
('', 'd41d8cd98f00b204e9800998ecf8427e'),
('', 'd41d8cd98f00b204e9800998ecf8427e'),
('', 'd41d8cd98f00b204e9800998ecf8427e'),
('', 'd41d8cd98f00b204e9800998ecf8427e'),
('abcd@gmail.com', 'e99a18c428cb38d5f260853678922e03'),
('nazaha', 'ac638a13498ffe51c65a6ae0bf7089fd'),
('naza@gmail.com', '04bfdb6d41255bb074b63afbc90a3667'),
('mohamednazahagmail.com', 'e5e24e7f10324a59cb61780de44a02c9'),
('dwq', 'dd3ba2cca7da8526615be73d390527ac'),
('', 'd41d8cd98f00b204e9800998ecf8427e'),
('', 'd41d8cd98f00b204e9800998ecf8427e'),
('', 'd41d8cd98f00b204e9800998ecf8427e'),
('nazad@gmail.com', 'e99a18c428cb38d5f260853678922e03'),
('', 'd41d8cd98f00b204e9800998ecf8427e'),
('', 'd41d8cd98f00b204e9800998ecf8427e'),
('', 'd41d8cd98f00b204e9800998ecf8427e'),
('', 'd41d8cd98f00b204e9800998ecf8427e'),
('abcd@gmail.com', 'a2042ae83ab3fc99639b5a2b447de093'),
('abcwfwetd@gmail.com', 'a2042ae83ab3fc99639b5a2b447de093'),
('infakqdqwf', 'a2042ae83ab3fc99639b5a2b447de093'),
('wqeqrf', '235abce2df49d0d5292cfb3c5acfe16b');

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

CREATE TABLE `payments` (
  `id` int(6) UNSIGNED NOT NULL,
  `card_holder` varchar(50) NOT NULL,
  `card_number` varchar(16) NOT NULL,
  `expiry_date` varchar(5) NOT NULL,
  `cvv` varchar(4) NOT NULL,
  `payment_date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `payments`
--

INSERT INTO `payments` (`id`, `card_holder`, `card_number`, `expiry_date`, `cvv`, `payment_date`) VALUES
(1, 'infak', '32465', '06', '556', '2024-05-14 16:17:25'),
(2, 'fs', '123', '12', '12', '2024-05-17 11:43:13'),
(3, 'gJH', '12', '12', '12', '2024-05-17 14:55:58'),
(4, 'naza', '56562', '25', '25', '2024-05-18 14:21:13'),
(5, 'infak', '20014', '06', '2', '2024-05-18 17:03:23'),
(6, 'ink', '25', '25', '25', '2024-05-19 06:37:13'),
(7, '212', '21', '25', '52', '2024-05-19 07:36:56'),
(8, 'infak', '12', '25', '25', '2024-05-19 09:52:35'),
(9, 'fs', '32465', '25', '12', '2024-05-19 09:55:15'),
(10, '45', '45', '45', '44', '2024-05-19 11:06:04'),
(11, 'infak', '12', '06', '12', '2024-05-19 17:20:29'),
(12, 'infak', '12', '06', '12', '2024-05-19 17:32:47'),
(13, '212', '12', '25', '25', '2024-05-19 18:05:15'),
(14, 'fs', '123', '12', '12', '2024-05-19 18:09:28'),
(15, '212', '32465', '06', '12', '2024-05-20 15:21:06'),
(16, 'infak', '676', '25/45', '12', '2024-05-29 13:39:06'),
(17, 'infak', '32465', '25', '12', '2024-05-29 13:42:56'),
(18, 'infak', '6246531232412345', '25', '112', '2024-05-30 06:54:48'),
(19, 'infak', '6246531232412345', '25', '112', '2024-07-07 06:02:44');

-- --------------------------------------------------------

--
-- Table structure for table `paymentsconfirmation`
--

CREATE TABLE `paymentsconfirmation` (
  `booking_id` int(11) NOT NULL,
  `user_name` varchar(255) DEFAULT NULL,
  `Email_id` varchar(255) DEFAULT NULL,
  `place` varchar(255) DEFAULT NULL,
  `Trip_days` int(11) DEFAULT NULL,
  `ondate` date DEFAULT NULL,
  `bookingdate` date DEFAULT NULL,
  `package` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `touriscount` int(10) DEFAULT NULL,
  `user_nic_no` varchar(255) DEFAULT NULL,
  `tripamount` decimal(10,2) DEFAULT NULL,
  `contactno` varchar(20) DEFAULT NULL,
  `id` int(13) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `paymentsconfirmation`
--

INSERT INTO `paymentsconfirmation` (`booking_id`, `user_name`, `Email_id`, `place`, `Trip_days`, `ondate`, `bookingdate`, `package`, `status`, `touriscount`, `user_nic_no`, `tripamount`, `contactno`, `id`) VALUES
(4, 'zama', 'mohamedinfak123@gmail.com', 'Jaffna', 5, '2024-05-23', '2024-05-21', ' cuple', 'confirmed', 2, ' 200116601497', 10000.00, '770203226', 83),
(5, 'nazaha fathima', 'infakstc@gmail.com', 'Jaffna', 5, '2024-05-07', '2024-05-14', ' cuple', 'confirmed', 2, ' 200116601497', 10000.00, '752217426', 84),
(6, 'infak', 'mohamedinfak123@gmail.com', 'Jaffna', 5, '2024-05-30', '2024-05-31', ' solo', 'confirmed', 2, ' 200116601497', 10000.00, '752211311', 85),
(7, 'MSTERMAIND', 'infakstc@gmail.com', 'Anuradhapura', 15, '2024-07-07', '2024-07-10', ' solo', 'confirmed', 6, ' 123456789012', 17910.00, '752211311', 86);

-- --------------------------------------------------------

--
-- Table structure for table `registerform`
--

CREATE TABLE `registerform` (
  `username` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `passwordcnf` varchar(100) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `actype` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `registerform`
--

INSERT INTO `registerform` (`username`, `email`, `password`, `passwordcnf`, `gender`, `actype`) VALUES
('Hacker', 'infak@gmail.com', '6edf26f6e0badff12fca32b16db38bf2', '6edf26f6e0badff12fca32b16db38bf2', 'Male', 'user'),
('Hacker', 'mohamedinfak@gmail.com', 'e64b78fc3bc91bcbc7dc232ba8ec59e0', 'e64b78fc3bc91bcbc7dc232ba8ec59e0', 'Male', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `tourpack`
--

CREATE TABLE `tourpack` (
  `id` int(15) NOT NULL,
  `packages` varchar(25) DEFAULT NULL,
  `districts` varchar(25) DEFAULT NULL,
  `no_of_pearson` int(100) DEFAULT NULL,
  `day_amount` int(100) DEFAULT NULL,
  `tripdays` int(100) DEFAULT NULL,
  `tourdescription` varchar(100) DEFAULT NULL,
  `imagepathe` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tourpack`
--

INSERT INTO `tourpack` (`id`, `packages`, `districts`, `no_of_pearson`, `day_amount`, `tripdays`, `tourdescription`, `imagepathe`) VALUES
(62, 'solo', 'Jaffna', 1, 1000, 5, 'If you’re planning on making the journey north to Jaffna on your Sri Lankan adventure (which we cert', 'IMG-668d0c1aeea336.98113734.jpg'),
(63, 'solo', 'Jaffna', 1, 1200, 10, 'From the minute we entered the grounds, this temple was unlike anything we’d ever seen before. From ', 'IMG-668d1f605b6940.32299081.jpg'),
(64, 'solo', 'Jaffna', 1, 1300, 15, 'Sunset views and peaceful ambience among historical ramparts and shady benches. Explore ancient ruin', 'IMG-668d2265379bd0.75995161.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `visitingplace`
--

CREATE TABLE `visitingplace` (
  `id` int(15) NOT NULL,
  `districts` text NOT NULL,
  `place` text NOT NULL,
  `placedescription` varchar(100) NOT NULL,
  `imagepathe` text DEFAULT NULL,
  `weblink` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `visitingplace`
--

INSERT INTO `visitingplace` (`id`, `districts`, `place`, `placedescription`, `imagepathe`, `weblink`) VALUES
(15, 'Hambantota', 'ham', 'gzfdgzfdgzsfsgtrgf', 'IMG-668d6938412762.00769549.jpg', 'http://localhost/TourisamManagementwebappe/addvisitingplace.php'),
(16, 'Jaffna', 'ham', 'vdgjhJKKJRHKJAHFHDJKAHDKJ', 'IMG-668d699203b145.37012982.jpg', 'http://localhost/TourisamManagementwebappe/addvisitingplace.php'),
(17, 'Ampara', 'ham', 'HGRHJJHGRJHJHJKHRKJQKJEKQ', 'IMG-668d69a81d9bf8.50827098.jpg', 'http://localhost/TourisamManagementwebappe/addvisitingplace.php');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `booking`
--
ALTER TABLE `booking`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `Email_id` (`Email_id`);

--
-- Indexes for table `bookingcancel`
--
ALTER TABLE `bookingcancel`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `bookingconfirmed`
--
ALTER TABLE `bookingconfirmed`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `enquiries`
--
ALTER TABLE `enquiries`
  ADD PRIMARY KEY (`report_id`);

--
-- Indexes for table `feedback`
--
ALTER TABLE `feedback`
  ADD PRIMARY KEY (`fid`);

--
-- Indexes for table `payments`
--
ALTER TABLE `payments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `paymentsconfirmation`
--
ALTER TABLE `paymentsconfirmation`
  ADD PRIMARY KEY (`booking_id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `registerform`
--
ALTER TABLE `registerform`
  ADD PRIMARY KEY (`email`);

--
-- Indexes for table `tourpack`
--
ALTER TABLE `tourpack`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `visitingplace`
--
ALTER TABLE `visitingplace`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `booking`
--
ALTER TABLE `booking`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=136;

--
-- AUTO_INCREMENT for table `bookingcancel`
--
ALTER TABLE `bookingcancel`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `bookingconfirmed`
--
ALTER TABLE `bookingconfirmed`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=87;

--
-- AUTO_INCREMENT for table `enquiries`
--
ALTER TABLE `enquiries`
  MODIFY `report_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `feedback`
--
ALTER TABLE `feedback`
  MODIFY `fid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=90;

--
-- AUTO_INCREMENT for table `payments`
--
ALTER TABLE `payments`
  MODIFY `id` int(6) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `paymentsconfirmation`
--
ALTER TABLE `paymentsconfirmation`
  MODIFY `booking_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `tourpack`
--
ALTER TABLE `tourpack`
  MODIFY `id` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=66;

--
-- AUTO_INCREMENT for table `visitingplace`
--
ALTER TABLE `visitingplace`
  MODIFY `id` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
